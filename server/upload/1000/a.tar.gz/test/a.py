def abc():
    print "hello"

